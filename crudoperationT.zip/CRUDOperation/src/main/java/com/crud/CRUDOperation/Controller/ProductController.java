package com.crud.CRUDOperation.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.crud.CRUDOperation.Entity.Product;
import com.crud.CRUDOperation.Repository.ProductRepository;

@RestController
public class ProductController {
    @Autowired
    ProductRepository repo;

    @GetMapping("/api/products")
    public Page<Product> getAllProducts(
            @RequestParam int page,
            @RequestParam int size) {
        Pageable pageable = PageRequest.of(page, size);
        return repo.findAll(pageable);
    }

    @GetMapping("/api/products/{id}")
    public Product getProduct(@PathVariable int id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found with ID: " + id));
    }

    @PostMapping("/api/products")
    @ResponseStatus(code = HttpStatus.CREATED)
    public void createProduct(@RequestBody Product product) {
    	repo.save(product);
    }

    @PutMapping("/api/products/{id}")
    public Product updateProduct(@PathVariable int id) {
        Product product = repo.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
        product.setName("Updated Name");
        product.setPrice(2000.0f);
        return repo.save(product);
    }

    @DeleteMapping("/api/products/{id}")
    public void removeProduct(@PathVariable int id) {
        Product product = repo.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
        repo.delete(product);
    }
}
